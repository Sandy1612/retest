package com.capgemini.flp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

@Repository
public class CabStoreDaoImpl implements ICapStoreDao{
	
	@PersistenceContext
	EntityManager em;
	
	
	
	
	

}
