package com.capgemini.flp.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {

	
	
	
}
