package com.capgemini.flp.dto;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="merchant")
public class Merchant {
	
	
	
	

}
