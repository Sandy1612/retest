package com.capgemini.flp.service;

public class CapStoreServiceImpl implements ICapStoreService{

}
